﻿using ClickToBuy.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace ClickToBuy.Manager.Contracts
{
    public interface IPurchasePaymentManager : IBaseManager<PurchasePayment> 
    {
    }
}
